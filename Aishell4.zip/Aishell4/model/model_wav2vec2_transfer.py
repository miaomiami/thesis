import torch
import torch.nn as nn
import pytorch_lightning as pl
from transformers import Wav2Vec2Model


class Wav2Vec2ForSpeakerClassification(pl.LightningModule):
    def __init__(
        self,
        pretrained_model_name="TencentGameMate/wav2vec2-large-chinese",
        num_classes=10,
        learning_rate=3e-5,
        freeze_feature_extractor=True,
        freeze_encoder_layers=8,
        pooling_method="mean+std"
    ):
        super().__init__()
        self.save_hyperparameters()

        # Load pretrained wav2vec2 model
        self.wav2vec2 = Wav2Vec2Model.from_pretrained(pretrained_model_name)

        # Freeze conv feature extractor
        if freeze_feature_extractor:
            self.wav2vec2.feature_extractor._freeze_parameters()

        # Freeze early transformer layers
        if freeze_encoder_layers > 0:
            for layer in self.wav2vec2.encoder.layers[:freeze_encoder_layers]:
                for param in layer.parameters():
                    param.requires_grad = False

        self.pooling_method = pooling_method
        hidden_size = self.wav2vec2.config.hidden_size

        # Compute input dim of classifier based on pooling type
        classifier_input_dim = hidden_size * 2 if pooling_method == "mean+std" else hidden_size

        # Multi-layer perceptron classifier
        self.classifier = nn.Sequential(
            nn.Linear(classifier_input_dim, 512),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(512, num_classes)
        )

        self.loss_fn = nn.CrossEntropyLoss()

    def _pool_hidden_states(self, hidden_states):
        """Pooling over time dimension (B, T, H) → (B, H or 2H)"""
        if self.pooling_method == "mean":
            return hidden_states.mean(dim=1)
        elif self.pooling_method == "max":
            return hidden_states.max(dim=1).values
        elif self.pooling_method == "mean+std":
            mean = hidden_states.mean(dim=1)
            std = hidden_states.std(dim=1)
            return torch.cat([mean, std], dim=1)
        else:
            raise ValueError(f"Unsupported pooling method: {self.pooling_method}")

    def forward(self, input_values, attention_mask=None, labels=None):
        outputs = self.wav2vec2(input_values, attention_mask=attention_mask)
        hidden_states = outputs.last_hidden_state  # (B, T, H)
        pooled = self._pool_hidden_states(hidden_states)
        logits = self.classifier(pooled)

        loss = self.loss_fn(logits, labels) if labels is not None else None
        preds = torch.argmax(logits, dim=1)

        return {"loss": loss, "logits": logits, "preds": preds}

    def training_step(self, batch, batch_idx):
        input_values, labels = batch
        outputs = self(input_values, labels=labels)
        self.log("train_loss", outputs["loss"], prog_bar=True)
        return outputs["loss"]

    def validation_step(self, batch, batch_idx):
        input_values, labels = batch
        outputs = self(input_values, labels=labels)
        acc = (outputs["preds"] == labels).float().mean()
        self.log("val_loss", outputs["loss"], prog_bar=True)
        self.log("val_acc", acc, prog_bar=True)
        return {"val_loss": outputs["loss"], "val_acc": acc}

    def configure_optimizers(self):
        optimizer = torch.optim.AdamW(self.parameters(), lr=self.hparams.learning_rate)
        scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=3, gamma=0.95)
        return [optimizer], [scheduler]
